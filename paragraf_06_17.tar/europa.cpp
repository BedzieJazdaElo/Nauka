// A oto plik europa.cpp:

#include <iostream>
using namespace std;

#include "nagl.h"
int ile_europejczykow = 8;
//****************************************************************
void funkcja_francuska()
{
 	cout << "Jestem w Paryzu! (Europa)  *********************\n";

 	cout << "Na swiecie mam przyjaciol:  "<< ile_pigmejow << " pigmejow, oraz "
 			<< ile_europejczykow << " europejczykow \n";

 	funkcja_etiopska();
}
//****************************************************************
void funkcja_niemiecka(void)
{
	cout << "Jestem w Berlinie! (Europa) *******************\n";

	cout << "Na swiecie mam przyjaciol:  " << ile_pigmejow << " pigmejow, oraz "
			<< ile_europejczykow << " europejczykow \n";
	funkcja_kenijska();
}
