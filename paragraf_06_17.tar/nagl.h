
//Tak wygląda zawartość pliku nagl.h

extern int ile_pigmejow;
extern int ile_europejczykow;

void funkcja_etiopska();
void funkcja_kenijska();
void funkcja_francuska();
void funkcja_niemiecka();
