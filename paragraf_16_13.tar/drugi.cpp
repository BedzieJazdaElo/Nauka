// Program z paragrafu 16_13
// plik drugi.cpp

//********************************************************************
// plik drugi.cpp
//********************************************************************
#include <iostream>
#include "Tbilet.h" 	 // bo w bieżącym pliku używamy klasy Tbilet 			`60
using namespace std;
//********************************************************************
void funkcja_w_innym_pliku()											// `61
{
	cout << "\nJestesmy w innym pliku programu, \ntu tez uzywamy biletow\n";
	Tbilet bialy;														// `62
	bialy.zapamietaj("Krakow", "Tarnow", Tbilet::osobowy);
	bialy.wypisz();

	cout << "Spieszy sie nam, zmieniamy bilet na taki:" << endl;
	bialy.zmien_rodzaj_pociagu(Tbilet::pospieszny);							// `63
	bialy.wypisz();
}
