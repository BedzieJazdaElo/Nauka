// Program z paragrafu 16_13_01
// Plik: Tosoba.cpp


//---------------------------------
// Plik: Tosoba.cpp
//---------------------------------
#include "Tosoba.h"  													// `20
using namespace std;
//********************************************************************
void Tosoba::zapamietaj(string napis, int lata)
{
	nazwisko = napis;
	wiek = lata;
}
