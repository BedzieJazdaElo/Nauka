// Program z paragrafu 16_13_01
// Plik: Tosoba.h

#ifndef TOSOBA_H        												// `10
#define TOSOBA_H
//**************************************
// Plik: Tosoba.h
//**************************************
#include <iostream>
#include <string>
//********************************************************************
class Tosoba
{
	std::string 	nazwisko;
	int wiek;
public:
	void wypisz()														// `11
	{
		std::cout << nazwisko << ", lat: " << wiek << std::endl;
	}
	void zapamietaj(std::string napis, int lata);								// `12
};
//********************************************************************
#endif
