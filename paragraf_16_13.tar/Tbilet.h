// Program z paragrafu 16_11
// Plik: Tbilet.h

#ifndef TBILET_H_													//`30
#define TBILET_H_
//------------------------------------
// Plik: Tbilet.h
//------------------------------------
#include <string>
//************************************************************************
class Tbilet															// `31
{
public:
	enum Trodzaj_pociagu {osobowy, przyspieszony, pospieszny, ekspres }; 		// `32

	void zapamietaj(	std::string sk,  std::string dok,  Trodzaj_pociagu poc, int kl = 2); 	// `33
	void wypisz();
	void zmien_rodzaj_pociagu(Trodzaj_pociagu poc);						// `34
private:
	std::string 		skad;
	std::string 		dokad;
	int  				klasa_kolejowa;
	Trodzaj_pociagu 	jaki_pociag;
	std::string 		opis_rodzaju();
	static int wydrukowano_biletow ;  									//    	`35
};
//************************************************************************
inline void Tbilet::zmien_rodzaj_pociagu(Trodzaj_pociagu poc)				// `36
{
	jaki_pociag = poc;
}
#endif
