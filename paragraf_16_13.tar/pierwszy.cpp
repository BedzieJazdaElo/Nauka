// Program z paragrafu 16_13
// plik  pierwszy.cpp

//********************************************************************
// plik  pierwszy.cpp
//********************************************************************
#include <iostream>
using namespace std;

#include "Tosoba.h"           												// `50
#include "Tbilet.h"														// `51

void prezentacja(Tosoba);
void funkcja_w_innym_pliku();  		// deklaracja funkcji z innego pliku
//********************************************************************
int main()															// `52
{
	Tosoba kompozytor;       											// `53
	Tosoba autor;
	kompozytor.zapamietaj("Fryderyk Chopin", 36);
	autor.zapamietaj("Marcel Proust", 34);
	// wywołujemy funkcję globalną , wysyłając jej obiekty
	prezentacja(kompozytor);
	prezentacja(autor);

	cout << "\nUzywamy w tym pliku tez klasy 'Tbilet'\n";

	Tbilet zolty, niebieski;												// `54
	zolty.zapamietaj("Frankfurt", "Paris", Tbilet::ekspres, 1);
	zolty.wypisz();

	niebieski.zapamietaj("Zurich", "Genewa", Tbilet::przyspieszony);
	niebieski.wypisz();

	niebieski.zmien_rodzaj_pociagu(Tbilet::pospieszny);						// `55
	cout << "\nPo zmianie tego biletu...\n";
	niebieski.wypisz();

	funkcja_w_innym_pliku();											// `56
}
//********************************************************************
void prezentacja(Tosoba ktos)           										// `57
{
	cout << "Mam zaszczyt przedstawic panstwu, \nOto we wlasnej osobie:  ";
	ktos.wypisz();
}
